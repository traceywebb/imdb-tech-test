package Page_Objects.Pages;

import Page_Objects.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ChartPage extends BasePage {

    private static final String PAGE_HEADER = "Top Rated Movies";

    @FindBy(className = "header") private WebElement topRatedHeader;
    @FindBy(className = "genre") private List<WebElement> genreDataList;
    @FindBy(className = "secondaryInfo") private List<WebElement> elementList;
    @FindBy(css = "#sidebar > div:nth-child(11) > span > ul > li:nth-child(5) > a") private WebElement comedyFilter;
    @FindBy(id = "lister-sort-by-options") private WebElement sortByDropDown;

    public void verifyPageHeader() {
        PageFactory.initElements(driver, this);
        assertEquals("Chart Page header did not match", PAGE_HEADER, topRatedHeader.getText());
    }

    public void refineGenreByComedy() {
        comedyFilter.click();
    }

    public void verifyListOfResults() {
        for (WebElement row: genreDataList){
            assertTrue("Genre does not contain comedy", row.getText().toLowerCase().contains("comedy"));
        }
    }

    public void sortTheListByReleaseDate() {
        Select dropDown = new Select(sortByDropDown);
        dropDown.selectByVisibleText("Release Date");
    }

    public void verifySortResults() {
        ArrayList<String> obtainedList = new ArrayList<String>();

        for(WebElement we:elementList){
            obtainedList.add(we.getText());
        }

        ArrayList<String> sortedList = new ArrayList<String>();
        sortedList.addAll(obtainedList);
        Collections.sort(sortedList);
        Collections.reverse(sortedList);

        assertTrue("Results are not in order of release date", sortedList.equals(obtainedList));
    }
}