package Page_Objects;

import org.junit.After;
import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasePage {

    protected static WebDriver driver = null;

    public static void openURL(String url) {
        String CHROME_DRIVER_LOCATION = "chromedriver\\chromedriver_win_74.0.3729.6.exe";
        System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_LOCATION);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to(url);
    }
}
