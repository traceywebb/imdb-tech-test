package step_definitions;

import Page_Objects.Pages.ChartPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import static Page_Objects.BasePage.openURL;

public class StepDefinitions {

    private ChartPage chartPage = new ChartPage();
    private static final String TOP_RATED_MOVIES_URL = "http://www.imdb.com/chart/top";

    @Given("^I load the Top Rated Movies page$")
    public void iLoadTheTopRatedMoviesPage() {
        openURL(TOP_RATED_MOVIES_URL);
        chartPage.verifyPageHeader();
    }

    @Given("^I refine by Genre (.*)$")
    public void iRefineByGenre(String genre) {
        chartPage.refineGenreByComedy();
    }

    @Then("^the list of movies should only contain relevant results$")
    public void verifyResults() {
        chartPage.verifyListOfResults();
    }

    @And("^I sort the list by (.*)$")
    public void iSortTheListBy(String releaseDate) {
        chartPage.sortTheListByReleaseDate();
    }

    @Then("^the list of movies should be displayed in order of release date$")
    public void theListOfMoviesShouldBeDisplayedInOrderOfReleaseDate() {
        chartPage.verifySortResults();
    }
}